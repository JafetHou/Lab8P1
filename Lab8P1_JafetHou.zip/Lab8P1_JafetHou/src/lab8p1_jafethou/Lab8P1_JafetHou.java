package lab8p1_jafethou;

import java.util.Scanner;

public class Lab8P1_JafetHou {

    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        Scanner leaent = new Scanner(System.in);
        Libro[][] libreria = null;
        boolean seguir = true;
        while (seguir) {
            System.out.println("1. Crear biblioteca");
            System.out.println("2. Modificar librero");
            System.out.println("3. Ingrese 3 para salir: ");
            int opc = leaent.nextInt();

            Libro B = new Libro();

            switch (opc) {
                case 1: {
                    System.out.println("Ingrese la cantidad de filas para el librero: ");
                    int filas = leaent.nextInt();

                    System.out.println("Ingrese la cantidad de columnas para el librero: ");
                    int colum = leaent.nextInt();

                    if (filas > 0 && colum > 0) {
                        libreria = new Libro[filas][colum];

                        for (int i = 0; i < filas; i++) {
                            for (int j = 0; j < colum; j++) {
                                System.out.println("Ingrese el titulo del libro: ");
                                String titulo = leer.nextLine();

                                System.out.println("Ingrese el escritor: ");
                                String escritor = leer.nextLine();

                                System.out.println("Ingrese el anio de publicacion: ");
                                int pub = leaent.nextInt();

                                Libro biblio = new Libro(titulo, escritor, pub);
                                libreria[i][j] = biblio;
                            }
                            System.out.println("El libro fue agregado exitosamente ");
                        }
                        System.out.println("El libro completo es: ");
                        for (int i = 0; i < filas; i++) {
                            for (int j = 0; j < colum; j++) {
                                System.out.print("[" + libreria[i][j].gettitulo() + "]");
                            }
                            System.out.println("");

                        }
                    } else {
                        System.out.println("Debe Ingresar filas o columnas mayor a 0");
                    }

                    break;
                }
                case 2: {
                    if (libreria != null){
                        boolean esta = false;
                        int fila = 0;
                        int colum = 0;
                        System.out.println("Ingrese el libro a cambiar");
                        System.out.println("Ingrese el titulo del libro: ");
                        String titulo = leer.nextLine();

                        System.out.println("Ingrese el escritor: ");
                        String escritor = leer.nextLine();

                        System.out.println("Ingrese el anio de publicacion: ");
                        int pub = leaent.nextInt();
                        for (int i = 0; i < libreria.length; i++) {
                            for (int j = 0; j < libreria[0].length; j++) {
                                if (libreria[i][j].gettitulo().equals(titulo) && libreria[i][j].getescritor().equals(escritor) && libreria[i][j].getpublic() == pub) {
                                    esta = true;
                                    fila = i;
                                    colum = j;
                                }
                            }

                        }
                        if (esta == true) {
                            System.out.println("El libro fue encontrado en fila "+fila+1+" columna "+colum+1);
                            System.out.println("Ingrese el libro a cambiar");
                            System.out.println("Ingrese el titulo del libro: ");
                            titulo = leer.nextLine();

                            System.out.println("Ingrese el escritor: ");
                            escritor = leer.nextLine();

                            System.out.println("Ingrese el anio de publicacion: ");
                            pub = leaent.nextInt();

                            libreria[fila][colum].settitulo(titulo);
                            libreria[fila][colum].setescritor(escritor);
                            libreria[fila][colum].setpublic(pub);
                            
                            for (int i = 0; i < libreria.length; i++) {
                                for (int j = 0; j < libreria[0].length; j++) {
                                
                                    System.out.print("["+libreria[i][j].gettitulo()+"]");
                                }
                                System.out.println("");
                            }
                            
                        } else {
                            System.out.println("El libro no fue encontrado");
                        }
                    }else{
                        System.out.println("No a ingresado nada en la biblioteca");
                    }
                    break;
                }
                case 3: {
                    seguir = false;
                    break;
                }
                default: {
                    break;
                }
            }
        }
    }

}
