
package lab8p1_jafethou;
import java.util.Scanner;


public class Libro {
    static Scanner leer = new Scanner(System.in);
    
    private String titulo;
    private String escritor;
    private int pub;
    
    public Libro(){
        
    }
    
    public Libro(String tituloN, String escritorN, int pubN){
        this.titulo = tituloN;
        this.escritor = escritorN;
        this.pub = pubN;
        
       
        return ;
        
    }
    public String gettitulo(){
        return this.titulo;
    }    
    public void settitulo(String tituloN){
        this.titulo= tituloN;
    }
    public String getescritor(){
        return this.escritor;
    }
    public void setescritor(String escritorN){
        this.escritor = escritorN;
    }
    public int getpublic(){
        return this.pub;
    }
    public void setpublic(int pubN){
        this.pub = pubN;
    }
    
}
